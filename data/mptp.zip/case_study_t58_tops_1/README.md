# Case study: t58_tops_1

This directory contains the data used for the ranking case study in Appendix C.2.

- `rankings.json`: top-1024 rankings for TW-GNN, TW-GNN-LFR, and Trigger + similarity.
- `labels.jsonl`: the 18 test pairs for this conjecture, in
  `[conjecture, premise, label]` form.
- `metrics.json`: AP, RR, and Recall@K recorded for the three methods.

`labels.jsonl` and `rankings.json` can be passed directly to
`scripts/evaluate_ranking.py`.  Rankings are ordered by descending score; ties
are broken by premise name.
